# Linear_Multiple_Regression
Simple Regression implementation using python and R
Simple Linear Regression:
Salary data contains years of experience of different employees in similar roles and their salary for that year of experience. Goal is to predict the salary of an employee with x years of experience, where x is in between min(YearsExperience) and max(YearsExperience).
Multiple Regression:
Dataset 50_Startups.csv: dataset contains data about 50 startups, their spend in R&D, administration, marketing spend, state of the headquarters of startup and profit each start up.
Problem is to find a model to predict the profit given the spend in R&D, administration, marketing spend, state of the headquarters of startup.



